
# NightieCo — Vite + React + TypeScript + Tailwind

A single‑page nighties storefront. Zero server — just static hosting.

## Dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy (Vercel — easiest)
1. Create a Vercel account and install the Vercel CLI (`npm i -g vercel`) or use the dashboard.
2. Push this folder to a new GitHub repo.
3. On Vercel, **New Project → Import** your repo.
4. Framework: *Vite* (auto-detected). Build Command: `npm run build`. Output Dir: `dist`.
5. Deploy. You’ll get a URL like `https://your-site.vercel.app`.

## Deploy (Netlify)
1. New site from Git.
2. Build command: `npm run build`
3. Publish directory: `dist`

## Deploy (GitHub Pages)
1. `npm run build`
2. Serve `dist/` with GitHub Pages (e.g., via `peaceiris/actions-gh-pages`).
