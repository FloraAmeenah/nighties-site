
import React from 'react'
import { motion } from 'framer-motion'
import { ShoppingBag, Search, Filter, ChevronRight, Star, Sparkles, Moon, Truck, ShieldCheck, Mail, Heart, Ruler, BadgeCheck } from 'lucide-react'

type Size = 'XS' | 'S' | 'M' | 'L' | 'XL'
type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating'

interface Product {
  id: number
  name: string
  price: number
  rating: number
  tag: string
  colors: string[]
  sizes: Size[]
  image: string
}

const PRODUCTS: Product[] = [
  { id: 1, name: 'CloudSoft Cotton Nightie', price: 34, rating: 4.7, tag: 'Bestseller', colors: ['Lavender','Ivory','Blush'], sizes: ['S','M','L','XL'], image: 'https://images.unsplash.com/photo-1520975922284-9c5c3e8d8f13?q=80&w=1600&auto=format&fit=crop' },
  { id: 2, name: 'Moonlight Modal Slip', price: 42, rating: 4.8, tag: 'New', colors: ['Midnight','Sage'], sizes: ['XS','S','M','L'], image: 'https://images.unsplash.com/photo-1582582494700-1f0a5b2b3c98?q=80&w=1600&auto=format&fit=crop' },
  { id: 3, name: 'FeatherTouch Jersey Dress', price: 39, rating: 4.6, tag: 'Comfort', colors: ['Heather Grey','Plum'], sizes: ['S','M','L','XL'], image: 'https://images.unsplash.com/photo-1592878904946-b3cd9a9a5d67?q=80&w=1600&auto=format&fit=crop' },
  { id: 4, name: 'Luna Lace Nightdress', price: 55, rating: 4.5, tag: 'Elegant', colors: ['Pearl','Black'], sizes: ['S','M','L'], image: 'https://images.unsplash.com/photo-1560972550-aba3456a9d7c?q=80&w=1600&auto=format&fit=crop' },
  { id: 5, name: 'CoolBreeze Bamboo Nightie', price: 49, rating: 4.9, tag: 'Eco', colors: ['Mist','Ocean'], sizes: ['S','M','L','XL'], image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?q=80&w=1600&auto=format&fit=crop' },
  { id: 6, name: 'Stargazer Button Nightshirt', price: 44, rating: 4.4, tag: 'Classic', colors: ['Sky','Stripe'], sizes: ['XS','S','M','L','XL'], image: 'https://images.unsplash.com/photo-1544441892-87af52f8b49d?q=80&w=1600&auto=format&fit=crop' },
]

function StarRating({ value }: { value: number }) {
  const clamped = Math.max(0, Math.min(5, value))
  const full = Math.floor(clamped)
  const half = clamped - full >= 0.5
  return (
    <div className="flex items-center gap-1" aria-label={`Rated ${clamped} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < full ? 'fill-current' : half && i === full ? 'fill-current opacity-60' : 'opacity-30'}`} />
      ))}
      <span className="ml-1 text-xs text-slate-500">{clamped.toFixed(1)}</span>
    </div>
  )
}

function Pill({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs ${className}`}>{children}</span>
}

export default function App() {
  const [query, setQuery] = React.useState('')
  const [sort, setSort] = React.useState<SortKey>('featured')
  const [active, setActive] = React.useState<Product | null>(null)

  const filtered = React.useMemo(() => {
    const q = query.toLowerCase()
    let items = PRODUCTS.filter(p => p.name.toLowerCase().includes(q))
    switch (sort) {
      case 'price-asc': items = [...items].sort((a,b)=>a.price-b.price); break
      case 'price-desc': items = [...items].sort((a,b)=>b.price-a.price); break
      case 'rating': items = [...items].sort((a,b)=>b.rating-a.rating); break
      default: break
    }
    return items
  }, [query, sort])

  return (
    <div>
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
          <a href="#" className="flex items-center gap-2">
            <motion.div initial={{opacity:0,y:-6}} animate={{opacity:1,y:0}} className="rounded-xl bg-violet-600 p-2 text-white">
              <Moon className="h-5 w-5" />
            </motion.div>
            <span className="font-semibold tracking-tight">NightieCo</span>
          </a>
          <nav className="ml-auto hidden items-center gap-6 text-sm text-slate-600 md:flex">
            <a href="#collection" className="hover:text-slate-900">Collection</a>
            <a href="#comfort" className="hover:text-slate-900">Comfort</a>
            <a href="#about" className="hover:text-slate-900">About</a>
            <a href="#contact" className="hover:text-slate-900">Contact</a>
          </nav>
          <div className="ml-2 hidden items-center gap-2 sm:flex">
            <div className="relative">
              <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search nighties…" aria-label="Search" className="w-64 rounded-full border bg-white pl-9 pr-3 py-2 text-sm outline-none ring-1 ring-black/5 focus:ring-2" />
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
            <button className="rounded-full border px-3 py-2 text-sm"><ShoppingBag className="mr-2 inline h-4 w-4"/>Bag</button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 md:grid-cols-2 md:py-20">
          <div>
            <motion.h1 initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{duration:0.6}} className="text-4xl font-bold tracking-tight md:text-5xl">
              Nighties that feel like <span className="text-violet-700">dreams</span>
            </motion.h1>
            <p className="mt-4 max-w-prose text-slate-600">Breathable fabrics, gentle finishes, and considered silhouettes — designed for deep sleep and slow mornings.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#collection" className="rounded-full bg-violet-700 px-5 py-3 text-sm font-medium text-white inline-flex items-center">Shop collection <ChevronRight className="ml-1 h-4 w-4"/></a>
              <a href="#about" className="rounded-full border px-5 py-3 text-sm font-medium inline-flex items-center">Our story</a>
            </div>
            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Perk icon={Truck} title="Free UK Delivery" text="on orders over £50" />
              <Perk icon={ShieldCheck} title="90-Day Returns" text="easy, no-fuss" />
              <Perk icon={Moon} title="Night-Soft Fabrics" text="cotton · modal · bamboo" />
              <Perk icon={BadgeCheck} title="Ethically Made" text="small-batch partners" />
            </div>
          </div>
          <motion.div initial={{opacity:0,scale:0.98}} animate={{opacity:1,scale:1}} className="relative">
            <div className="aspect-[4/5] overflow-hidden rounded-3xl shadow-xl ring-1 ring-black/5">
              <img src="https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?q=80&w=1600&auto=format&fit=crop" alt="Soft nightie by a sunlit window" className="h-full w-full object-cover" />
            </div>
            <span className="absolute -left-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-violet-700 ring-1 ring-black/5 text-xs"><Sparkles className="h-3.5 w-3.5"/> New season</span>
          </motion.div>
        </div>
      </section>

      {/* Controls */}
      <section id="collection" className="border-t bg-white/60 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <button className="rounded-full border px-3 py-2 text-sm"><Filter className="mr-2 inline h-4 w-4"/>Filters</button>
            <div className="rounded-full border px-2 py-1 text-xs">
              <button className="rounded-full px-3 py-1 hover:bg-slate-100">All</button>
              <button className="rounded-full px-3 py-1 hover:bg-slate-100">Cotton</button>
              <button className="rounded-full px-3 py-1 hover:bg-slate-100">Modal</button>
              <button className="rounded-full px-3 py-1 hover:bg-slate-100">Bamboo</button>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex-1 sm:hidden">
              <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search nighties…" className="w-full rounded-full border px-3 py-2 text-sm"/>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-600">Sort</span>
              <select value={sort} onChange={e=>setSort(e.target.value as SortKey)} className="w-40 rounded-full border px-3 py-2 text-sm">
                <option value="featured">Featured</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Top Rated</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="py-10">
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map(p => (
              <motion.div key={p.id} initial={{opacity:0,y:12}} whileInView={{opacity:1,y:0}} viewport={{once:true}}>
                <article className="group overflow-hidden rounded-2xl border bg-white shadow-sm transition-shadow hover:shadow-md">
                  <div className="relative aspect-[4/5] overflow-hidden">
                    <img src={p.image} alt={p.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy"/>
                    <span className="absolute left-3 top-3 rounded-full bg-violet-600/90 px-3 py-1 text-xs text-white">{p.tag}</span>
                    <button aria-label="Save" className="absolute right-3 top-3 h-9 w-9 rounded-full bg-white/90 ring-1 ring-black/5 grid place-items-center"><Heart className="h-4 w-4"/></button>
                  </div>
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-medium leading-tight">{p.name}</h3>
                        <div className="mt-1"><StarRating value={p.rating}/></div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-semibold">£{p.price.toFixed(2)}</p>
                        <p className="text-xs text-slate-500">incl. VAT</p>
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {p.colors.map(c => (<Pill key={c} className="text-slate-500">{c}</Pill>))}
                    </div>
                    <div className="mt-4 flex items-center gap-2">
                      <button onClick={()=>setActive(p)} className="flex-1 rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white">Quick view</button>
                      <button className="flex-1 rounded-full border px-4 py-2 text-sm"><ShoppingBag className="mr-2 inline h-4 w-4"/>Add</button>
                    </div>
                  </div>
                </article>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Comfort */}
      <section id="comfort" className="bg-gradient-to-b from-white to-violet-50">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2">
          <div>
            <h2 className="text-3xl font-semibold tracking-tight">Comfort, engineered softly</h2>
            <p className="mt-3 max-w-prose text-slate-600">We start with responsibly sourced cotton, modal, and bamboo, then finish garments with flat seams and brushed bindings so you barely feel them. Breathability and drape are tested on real bodies — all sizes.</p>
            <ul className="mt-6 grid grid-cols-2 gap-3 text-sm">
              <li className="rounded-xl border p-3">No-itch labels</li>
              <li className="rounded-xl border p-3">Lay-flat seams</li>
              <li className="rounded-xl border p-3">Cooling weaves</li>
              <li className="rounded-xl border p-3">Machine-wash easy</li>
            </ul>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-[4/5] overflow-hidden rounded-2xl shadow ring-1 ring-black/5"><img src="https://images.unsplash.com/photo-1592878904946-b3cd9a9a5d67?q=80&w=1200&auto=format&fit=crop" alt="Soft jersey detail" className="h-full w-full object-cover"/></div>
            <div className="aspect-[4/5] overflow-hidden rounded-2xl shadow ring-1 ring-black/5"><img src="https://images.unsplash.com/photo-1544441892-87af52f8b49d?q=80&w=1200&auto=format&fit=crop" alt="Nightshirt fabric" className="h-full w-full object-cover"/></div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section id="about" className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="rounded-3xl border bg-white/70 p-8 md:p-10">
            <div className="gap-8 md:flex md:items-center md:justify-between">
              <div className="max-w-xl">
                <h3 className="text-2xl font-semibold">Join the Night Letter</h3>
                <p className="mt-2 text-slate-600">Early access to drops, size restocks, and sleep tips that actually help.</p>
              </div>
              <form className="mt-6 flex w-full max-w-md items-center gap-2 md:mt-0" onSubmit={e=>e.preventDefault()}>
                <input type="email" placeholder="you@domain.com" className="w-full rounded-full border px-3 py-2 text-sm" aria-label="Email" />
                <button className="rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white"><Mail className="mr-2 inline h-4 w-4"/>Subscribe</button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <hr className="border-slate-200" />

      {/* Footer */}
      <footer id="contact" className="py-12">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2"><div className="rounded-xl bg-violet-600 p-2 text-white"><Moon className="h-5 w-5"/></div><span className="font-semibold">NightieCo</span></div>
            <p className="mt-3 max-w-xs text-sm text-slate-600">Soft, ethical nightwear for deep rest and gentle mornings.</p>
          </div>
          <div>
            <p className="text-sm font-medium">Shop</p>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li><a href="#collection" className="hover:text-slate-900">All nighties</a></li>
              <li><a href="#collection" className="hover:text-slate-900">Cotton</a></li>
              <li><a href="#collection" className="hover:text-slate-900">Modal</a></li>
              <li><a href="#collection" className="hover:text-slate-900">Bamboo</a></li>
            </ul>
          </div>
          <div>
            <p className="text-sm font-medium">Company</p>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li><a href="#about" className="hover:text-slate-900">About us</a></li>
              <li><a href="#" className="hover:text-slate-900">Sustainability</a></li>
              <li><a href="#" className="hover:text-slate-900">Careers</a></li>
            </ul>
          </div>
          <div>
            <p className="text-sm font-medium">Help</p>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li><a href="#" className="hover:text-slate-900">Shipping</a></li>
              <li><a href="#" className="hover:text-slate-900">Returns</a></li>
              <li><a href="#" className="hover:text-slate-900">Size guide</a></li>
            </ul>
          </div>
        </div>
        <div className="mx-auto mt-10 flex max-w-6xl flex-col items-center justify-between gap-4 px-4 text-xs text-slate-600 sm:flex-row">
          <p>© {new Date().getFullYear()} NightieCo. All rights reserved.</p>
          <div className="flex items-center gap-3">
            <a href="#" className="hover:text-slate-900">Privacy</a>
            <a href="#" className="hover:text-slate-900">Terms</a>
            <a href="#" className="hover:text-slate-900">Cookies</a>
          </div>
        </div>
      </footer>

      {/* Quick View Modal */}
      {active && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-xl">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="aspect-[4/5] overflow-hidden rounded-xl"><img src={active.image} alt={active.name} className="h-full w-full object-cover"/></div>
              <div>
                <div className="flex items-center justify-between">
                  <StarRating value={active.rating} />
                  <span className="text-lg font-semibold">£{active.price.toFixed(2)}</span>
                </div>
                <h3 className="mt-1 text-xl font-semibold">{active.name}</h3>
                <p className="mt-3 text-sm text-slate-600">Gentle drape, breathable hand-feel. Ideal for warm sleepers and cool nights alike.</p>
                <div className="mt-4">
                  <p className="text-sm font-medium">Colour</p>
                  <div className="mt-2 flex flex-wrap gap-2">{active.colors.map(c => (<Pill key={c}>{c}</Pill>))}</div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between"><p className="text-sm font-medium">Size</p><span className="text-xs text-slate-500 inline-flex items-center"><Ruler className="mr-1 h-4 w-4"/>True to size</span></div>
                  <div className="mt-2 flex flex-wrap gap-2">{active.sizes.map(s => (<Pill key={s}>{s}</Pill>))}</div>
                </div>
                <div className="mt-6 flex gap-3">
                  <button className="flex-1 rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white"><ShoppingBag className="mr-2 inline h-4 w-4"/>Add to bag</button>
                  <button className="rounded-full border px-4 py-2 text-sm">Save <Heart className="ml-2 inline h-4 w-4"/></button>
                </div>
              </div>
            </div>
            <div className="mt-6 text-right"><button onClick={()=>setActive(null)} className="rounded-full border px-4 py-2 text-sm">Close</button></div>
          </div>
        </div>
      )}
    </div>
  )
}

function Perk({ icon: Icon, title, text }: { icon: React.ComponentType<any>, title: string, text: string }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border p-4">
      <div className="rounded-xl bg-slate-100 p-2"><Icon className="h-5 w-5"/></div>
      <div>
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xs text-slate-600">{text}</p>
      </div>
    </div>
  )
}
